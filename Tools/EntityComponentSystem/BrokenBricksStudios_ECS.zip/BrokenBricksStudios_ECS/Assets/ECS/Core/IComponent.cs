﻿namespace ECS {
    public interface IComponent {
    }
}