﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MessagePack")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("b23e464e-0ac2-47c9-9520-ea98cbb99575")]
[assembly: AssemblyVersion("1.7.2")]
[assembly: AssemblyFileVersion("1.7.2")]

// sn.exe -Tp
//[assembly: InternalsVisibleTo("MessagePack.Tests, PublicKey=" +
//"0024000004800000940000000602000000240000525341310004000001000100293894d4e8ad2b" +
//"53afbea4e949ef54c2a388b08b5ebd143c811da82f22aa20c839ed1c0b4da83e7195e8c1dbe1bf" +
//"3934e4e8fd7fb93f893439106fbf055a97c7fac0f7f8c39e58e78371dc0e3825e5b9d7e2afff03" +
//"72f03c4d67ff7df0dbfb58dcadeb1044840de152bf8270de7fc54255ace8efd026c16311760d1a" +
//"2570c3e8")]