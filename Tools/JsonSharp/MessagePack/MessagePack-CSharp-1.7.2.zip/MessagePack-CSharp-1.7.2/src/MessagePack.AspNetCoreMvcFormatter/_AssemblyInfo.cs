﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("MessagePack.AspNetCoreMvcFormatter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("7c1f59ed-3929-4cbb-8aca-b13139fbca3a")]
[assembly: AssemblyVersion("1.7.2")]
[assembly: AssemblyFileVersion("1.7.2")]
