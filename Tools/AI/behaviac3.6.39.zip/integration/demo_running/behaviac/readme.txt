What is behaviac?
------------------------------------------
Behaviac is the solution for the BT(behavior tree), FMS(finite state machine), HTN(hierarchical task network).

What is in this package?
------------------------------------------
This package is only the runtime. It can be imported into your projects.


More Information
------------------------------------------
This package is only the runtime. It can be imported into your projects.
The runtime uses the exported files from the Designer, to make it work, you need to:

1. Goto https://github.com/TencentOpen/behaviac/releases download the prebuilt binary
	1. Which contains the Designer, to design/debug the behaviors
	2. the Designer UI supports Chinese and English, which can be switched from File->Settings->Languange
	3. The Designer can only run on the Windows platforms
	4. The runtime has c# version(this package) and c++ port which supports all major platforms (Windows, Linux, Android, iOS, Unity etc.)
	5. All source codes including Designer and runtime are provided at https://github.com/TencentOpen/behaviac/)
	
2. You can access the Overview http://www.behaviac.com/docs/en/articles/overview/ or in the Designer from the Help Menu.

